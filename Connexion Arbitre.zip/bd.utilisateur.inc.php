<?php

include "bd.inc.php";

//ARBITRE

function getArbitreByMailU($mailU) {
    $resultat = array();

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("select nom_arbitre, prenom_arbitre, adresse_arbitre, CP_arbitre, ville_arbitre, date_naiss_arbitre, tel_fixe_arbitre, tel_port_arbitre, mailU, nom_club, mdpU
        from arbitre inner join club on arbitre.num_club = club.num_club where mailU = :mailU");
        $req->bindValue(':mailU', $mailU, PDO::PARAM_STR);
        $req->execute();

        $resultat = $req->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
    return $resultat;
}

function insertArbitre(
    $nomArbitre,
    $prenomArbitre,
    $adrArbitre,
    $cpArbitre,
    $villeArbitre,
    $datenaissArbitre,
    $telfixeArbitre,
    $telportArbitre,
    $mailU,
    $numClub,
    $numEquipe,
    $mdpU
) {
    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("INSERT INTO arbitre VALUES (NULL, :nomArbitre, :prenomArbitre, :adrArbitre, :cpArbitre, :villeArbitre,
                            :datenaissArbitre, :telfixeArbitre, :telportArbitre, :mailU, :numClub, :numEquipe, :mdpU)");
        $req->execute(array(
            'nomArbitre' => $nomArbitre,
            'prenomArbitre' => $prenomArbitre,
            'adrArbitre' => $adrArbitre,
            'cpArbitre' => $cpArbitre,
            'villeArbitre' => $villeArbitre,
            'datenaissArbitre' => $datenaissArbitre,
            'telfixeArbitre' => $telfixeArbitre,
            'telportArbitre' => $telportArbitre,
            'mailU' => $mailU,
            'numClub' => $numClub,
            'numEquipe' => $numEquipe,
            'mdpU' => $mdpU
        ));
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
}

//RESPONSABLE

function getResponsableByMailU($mailU) {
    $resultat = array();

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("select *
                            from responsable
                            where mailU=:mailU");
        $req->bindValue(':mailU', $mailU, PDO::PARAM_STR);
        $req->execute();

        $resultat = $req->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
    return $resultat;
}

function insertResponsable($mailResponsable, $mdpResponsable
) {
    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("INSERT INTO responsable VALUES (NULL, :mailResponsable, :mdpResponsable)");
        $req->execute(array(
            'mailResponsable' => $mailResponsable,
            'mdpResponsable' => $mdpResponsable
        ));
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
}