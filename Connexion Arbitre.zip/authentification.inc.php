<?php

include_once "bd.utilisateur.inc.php";

//ARBITRE

function loginArbitre($mailU, $mdpU)
{
    if (!isset($_SESSION)) {
        session_start();
    }

    $util = getArbitreByMailU($mailU);
    $mdpBD = $util["mdpU"];

    if (trim($mdpBD) == trim(crypt($mdpU, $mdpBD))) {
        // le mot de passe est celui de l'utilisateur dans la base de donnees
        $_SESSION["mailU"] = $mailU;
        $_SESSION["mdpU"] = $mdpBD;
    }
}

function logoutArbitre()
{
    if (!isset($_SESSION)) {
        session_start();
    }
    unset($_SESSION["mailU"]);
    unset($_SESSION["mdpU"]);
}

function getMailULoggedOnArbitre()
{
    if (isLoggedOnArbitre()) {
        $ret = $_SESSION["mailU"];
    } else {
        $ret = "";
    }
    return $ret;
}

function isLoggedOnArbitre()
{
    if (!isset($_SESSION)) {
        session_start();
    }
    $ret = false;

    if (isset($_SESSION["mailU"])) {
        $util = getArbitreByMailU($_SESSION["mailU"]);
        if (
            $util["mailU"] == $_SESSION["mailU"] && $util["mdpU"] == $_SESSION["mdpU"]
        ) {
            $ret = true;
        }
    }
    return $ret;
}

//RESPONSABLE

function loginResponsable($mailU, $mdpU)
{
    if (!isset($_SESSION)) {
        session_start();
    }

    $util = getResponsableByMailU($mailU);
    $mdpBD = $util["mdpU"];

    if (trim($mdpBD) == trim(crypt($mdpU, $mdpBD))) {
        // le mot de passe est celui de l'utilisateur dans la base de donnees
        $_SESSION["mailU"] = $mailU;
        $_SESSION["mdpU"] = $mdpBD;
    }
}

function logoutResponsable()
{
    if (!isset($_SESSION)) {
        session_start();
    }
    unset($_SESSION["mailU"]);
    unset($_SESSION["mdpU"]);
}

function getMailULoggedOnResponsable()
{
    if (isLoggedOnResponsable()) {
        $ret = $_SESSION["mailU"];
    } else {
        $ret = "";
    }
    return $ret;
}

function isLoggedOnResponsable()
{
    if (!isset($_SESSION)) {
        session_start();
    }
    $ret = false;

    if (isset($_SESSION["mailU"])) {
        $util = getResponsableByMailU($_SESSION["mailU"]);
        if (
            $util["mailU"] == $_SESSION["mailU"] && $util["mdpU"] == $_SESSION["mdpU"]
        ) {
            $ret = true;
        }
    }
    return $ret;
}