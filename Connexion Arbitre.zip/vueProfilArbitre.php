<style type="text/css">
    @import url("css/hello.css");

    h5 {
        color: #FAEBC4
    }
</style>

<fieldset name="profilarb">
    <h5>Informations Arbitre</h5>
    <h7><B>Nom : </B><?= $util["nom_arbitre"] ?></h7>
    <h7><B>Prénom :</B> <?= $util["prenom_arbitre"] ?></h7></br>
    <h8><B>Date de naissance :</B> <?= $util["date_naiss_arbitre"] ?></h8></br></br></br>
    <h8><B>Adresse :</B> <?= $util["adresse_arbitre"] ?></h8>
    <h8><B>Code Postal : </B><?= $util["CP_arbitre"] ?></h8>
    <h8><B>Ville :</B> <?= $util["ville_arbitre"] ?></h8><br /><br /></br>
    <h8><B>Téléphone fixe : </B><?= $util["tel_fixe_arbitre"] ?></h8></br></br>
    <h8><B>Téléphone portable :</B> <?= $util["tel_port_arbitre"] ?></h8></br></br></br>
    <h8><B>Adresse e-mail :</B> <?= $util["mail_arbitre"] ?></h8></br></br></br>
    <h8><B>Appartient au club : </B><?= $util["nom_club"] ?></h8>
   